# Mapa de categorias do Nibo usadas no envio

CATEGORIES = {
    # Receitas
    "HONORARIOS_IN": "f82dbbe9-d73a-4c3a-954a-768753e65baf",     #ok      # Honorários de Cobrança (in)
    "REPASSES_IN":   "65de4e69-469c-4524-b4ee-143a6ef93531",     #ok       # Repasses a Clientes (in)
    "REEMBOLSOS_IN": "b403ac00-e58b-494d-b902-bc0c96f96765",     #ok       # Reembolsos (in)

    # Despesas / Pagamentos
    "REPASSES_OUT":              "5c4f0300-8dd3-43d9-803d-8b131c0b8288", #ok  # Repasses a Clientes (out)
    "GASTOS_REEMBOLSAVEIS_OUT":  "ad62fd0f-389d-46d5-b152-ddd7af04ce7f", #ok  # Gastos Reembolsáveis (out)

    # Regras AM3 (50/50 e 60/40)
    "HON_50_50_IN":  "6ae03893-c6d0-4bf5-9477-e598fbf1da98",  #ok
    "HON_50_50_OUT": "6714d679-2b8c-41e7-b512-d5ca12c28807",  #ok
    "HON_60_40_IN":  "342989dc-d914-4023-9fd5-71106a23cd91",  #ok
    "HON_60_40_OUT": "943e14b0-df1e-4f81-b8b5-ca0e942077c9",  #ok
}
